package com.mycompany.mavenproject4;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class MessageTest {

    // =====================================================
    // TEST 1: Message is within 250 characters
    // =====================================================
    @Test
    public void testMessageLengthSuccess() {

        Message message = new Message(
                "0012345678",
                0,
                "+27718693002",
                "Hi Mike, can you join us for dinner tonight?"
        );

        assertEquals(
                "Message ready to send.",
                message.checkMessageLength()
        );
    }

    // =====================================================
    // TEST 2: Message exceeds 250 characters
    // =====================================================
    @Test
    public void testMessageLengthFailure() {

        StringBuilder longMessage = new StringBuilder();

        for (int i = 0; i < 260; i++) {
            longMessage.append("A");
        }

        Message message = new Message(
                "0012345678",
                0,
                "+27718693002",
                longMessage.toString()
        );

        assertEquals(
                "Message exceeds 250 characters by 10, "
                + "please reduce the size.",
                message.checkMessageLength()
        );
    }

    // =====================================================
    // TEST 3: Recipient cellphone number is correct
    // =====================================================
    @Test
    public void testRecipientCorrectlyFormatted() {

        Message message = new Message(
                "0012345678",
                0,
                "+27718693002",
                "Hi Mike, can you join us for dinner tonight?"
        );

        assertEquals(
                "Cell phone number successfully captured.",
                message.checkRecipientCell()
        );
    }

    // =====================================================
    // TEST 4: Recipient cellphone number is incorrect
    // =====================================================
    @Test
    public void testRecipientIncorrectlyFormatted() {

        Message message = new Message(
                "0012345678",
                1,
                "08575975889",
                "Hi Keegan, did you receive the payment?"
        );

        assertEquals(
                "Cell phone number is incorrectly formatted or does "
                + "not contain an international code. Please correct "
                + "the number and try again.",
                message.checkRecipientCell()
        );
    }

    // =====================================================
    // TEST 5: Message ID is successfully generated
    // =====================================================
    @Test
    public void testMessageIDCreated() {

        String messageID = Message.generateMessageID();

        Message message = new Message(
                messageID,
                0,
                "+27718693002",
                "Hi Mike, can you join us for dinner tonight?"
        );

        assertTrue(message.checkMessageID());

        assertEquals(
                10,
                messageID.length()
        );
    }

    // =====================================================
    // TEST 6: Message ID longer than 10 characters
    // =====================================================
    @Test
    public void testMessageIDIncorrect() {

        Message message = new Message(
                "00123456789",
                0,
                "+27718693002",
                "Hi Mike, can you join us for dinner tonight?"
        );

        assertFalse(
                message.checkMessageID()
        );
    }

    // =====================================================
    // TEST 7: Message Hash
    // =====================================================
    @Test
    public void testMessageHash() {

        Message message = new Message(
                "0012345678",
                0,
                "+27718693002",
                "Hi Mike, can you join us for dinner tonight?"
        );

        assertEquals(
                "00:0:HITONIGHT",
                message.createMessageHash()
        );
    }

    // =====================================================
    // TEST 8: First message details
    // =====================================================
    @Test
    public void testFirstMessageDetails() {

        Message message = new Message(
                "0012345678",
                0,
                "+27718693002",
                "Hi Mike, can you join us for dinner tonight?"
        );

        assertEquals(
                "0012345678",
                message.getMessageID()
        );

        assertEquals(
                0,
                message.getMessageNumber()
        );

        assertEquals(
                "+27718693002",
                message.getRecipient()
        );

        assertEquals(
                "Hi Mike, can you join us for dinner tonight?",
                message.getMessage()
        );
    }

    // =====================================================
    // TEST 9: Second message details
    // =====================================================
    @Test
    public void testSecondMessageDetails() {

        Message message = new Message(
                "0012345679",
                1,
                "08575975889",
                "Hi Keegan, did you receive the payment?"
        );

        assertEquals(
                "0012345679",
                message.getMessageID()
        );

        assertEquals(
                1,
                message.getMessageNumber()
        );

        assertEquals(
                "08575975889",
                message.getRecipient()
        );

        assertEquals(
                "Hi Keegan, did you receive the payment?",
                message.getMessage()
        );
    }
}
