package com.mycompany.mavenproject4;

import javax.swing.JOptionPane;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;

public class Message {

    private String messageID;
    private int messageNumber;
    private String recipient;
    private String message;

    private static int totalMessages = 0;

    private static ArrayList<String> sentMessages
            = new ArrayList<>();

    // Constructor
    public Message(String messageID,
                   int messageNumber,
                   String recipient,
                   String message) {

        this.messageID = messageID;
        this.messageNumber = messageNumber;
        this.recipient = recipient;
        this.message = message;
    }

    // =====================================================
    // GENERATE MESSAGE ID
    // =====================================================

    public static String generateMessageID() {

        Random random = new Random();

        StringBuilder id = new StringBuilder();

        for (int i = 0; i < 10; i++) {
            id.append(random.nextInt(10));
        }

        return id.toString();
    }

    // =====================================================
    // CHECK MESSAGE ID
    // =====================================================

    public boolean checkMessageID() {

        return messageID != null
                && messageID.length() <= 10;
    }

    // =====================================================
    // CHECK RECIPIENT CELLPHONE
    // =====================================================

    public String checkRecipientCell() {

        if (recipient != null
                && recipient.matches("^\\+\\d{10,12}$")) {

            return "Cell phone number successfully captured.";
        }

        return "Cell phone number is incorrectly formatted or does "
                + "not contain an international code. Please correct "
                + "the number and try again.";
    }

    // =====================================================
    // CHECK MESSAGE LENGTH
    // =====================================================

    public String checkMessageLength() {

        if (message == null) {
            return "Message cannot be empty.";
        }

        if (message.length() <= 250) {

            return "Message ready to send.";
        }

        int extraCharacters
                = message.length() - 250;

        return "Message exceeds 250 characters by "
                + extraCharacters
                + ", please reduce the size.";
    }

    // =====================================================
    // CREATE MESSAGE HASH
    // =====================================================

    public String createMessageHash() {

        if (message == null
                || message.trim().isEmpty()) {

            return "";
        }

        String[] words
                = message.trim().split("\\s+");

        // Remove punctuation
        String firstWord
                = words[0].replaceAll(
                        "[^a-zA-Z0-9]",
                        ""
                );

        String lastWord
                = words[words.length - 1]
                        .replaceAll(
                                "[^a-zA-Z0-9]",
                                ""
                        );

        String firstTwoNumbers;

        if (messageID != null
                && messageID.length() >= 2) {

            firstTwoNumbers
                    = messageID.substring(0, 2);

        } else {

            firstTwoNumbers = messageID;
        }

        return (firstTwoNumbers
                + ":"
                + messageNumber
                + ":"
                + firstWord
                + lastWord).toUpperCase();
    }

    // =====================================================
    // SEND / DISCARD / STORE MESSAGE
    // =====================================================

    public String SentMessage() {

        String[] options = {
            "Send Message",
            "Disregard Message",
            "Store Message"
        };

        int choice
                = JOptionPane.showOptionDialog(
                        null,
                        "What would you like to do "
                        + "with this message?",
                        "QuickChat",
                        JOptionPane.DEFAULT_OPTION,
                        JOptionPane.INFORMATION_MESSAGE,
                        null,
                        options,
                        options[0]
                );

        // SEND
        if (choice == 0) {

            totalMessages++;

            String details
                    = "Message ID: "
                    + messageID
                    + "\nMessage Hash: "
                    + createMessageHash()
                    + "\nRecipient: "
                    + recipient
                    + "\nMessage: "
                    + message;

            sentMessages.add(details);

            return "Message successfully sent.";
        }

        // DISCARD
        if (choice == 1) {

            return "Press 0 to delete the message.";
        }

        // STORE
        if (choice == 2) {

            storeMessage();

            return "Message successfully stored.";
        }

        return "Message not sent.";
    }

    // =====================================================
    // PRINT MESSAGES
    // =====================================================

    public String printMessages() {

        if (sentMessages.isEmpty()) {

            return "No messages have been sent.";
        }

        StringBuilder output
                = new StringBuilder();

        for (String sentMessage : sentMessages) {

            output.append(sentMessage);
            output.append("\n\n");
        }

        return output.toString();
    }

    // =====================================================
    // RETURN TOTAL MESSAGES
    // =====================================================

    public int returnTotalMessages() {

        return totalMessages;
    }

    // =====================================================
    // STORE MESSAGE IN JSON FILE
    // =====================================================

    public void storeMessage() {

        String jsonMessage
                = "{\n"
                + "  \"messageID\": \""
                + escapeJson(messageID)
                + "\",\n"
                + "  \"messageNumber\": "
                + messageNumber
                + ",\n"
                + "  \"recipient\": \""
                + escapeJson(recipient)
                + "\",\n"
                + "  \"message\": \""
                + escapeJson(message)
                + "\",\n"
                + "  \"messageHash\": \""
                + escapeJson(createMessageHash())
                + "\"\n"
                + "}\n";

        try (FileWriter writer
                = new FileWriter(
                        "storedMessages.json",
                        true
                )) {

            writer.write(jsonMessage);

        } catch (IOException e) {

            JOptionPane.showMessageDialog(
                    null,
                    "Error storing message: "
                    + e.getMessage()
            );
        }
    }

    // =====================================================
    // ESCAPE JSON CHARACTERS
    // =====================================================

    private String escapeJson(String value) {

        if (value == null) {

            return "";
        }

        return value
                .replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "\\r");
    }

    // =====================================================
    // GETTERS
    // =====================================================

    public String getMessageID() {

        return messageID;
    }

    public int getMessageNumber() {

        return messageNumber;
    }

    public String getRecipient() {

        return recipient;
    }

    public String getMessage() {

        return message;
    }

    // =====================================================
    // MAIN METHOD - RUN PART 2 DIRECTLY
    // =====================================================

    public static void main(String[] args) {

        JOptionPane.showMessageDialog(
                null,
                "Welcome to QuickChat."
        );

        String numberInput
                = JOptionPane.showInputDialog(
                        "How many messages would you like to enter?"
                );

        if (numberInput == null) {
            return;
        }

        int numberOfMessages;

        try {

            numberOfMessages
                    = Integer.parseInt(numberInput);

            if (numberOfMessages <= 0) {

                JOptionPane.showMessageDialog(
                        null,
                        "Please enter a number greater than zero."
                );

                return;
            }

        } catch (NumberFormatException e) {

            JOptionPane.showMessageDialog(
                    null,
                    "Please enter a valid number."
            );

            return;
        }

        int messagesCreated = 0;

        Message lastMessage = null;

        boolean running = true;

        // =================================================
        // QUICKCHAT MENU
        // =================================================

        while (running) {

            String menuChoice
                    = JOptionPane.showInputDialog(
                            "QuickChat\n\n"
                            + "1) Send Messages\n"
                            + "2) Show recently sent messages\n"
                            + "3) Quit\n\n"
                            + "Enter your choice:"
                    );

            if (menuChoice == null) {
                break;
            }

            switch (menuChoice) {

                // =========================================
                // OPTION 1 - SEND MESSAGE
                // =========================================

                case "1":

                    if (messagesCreated
                            >= numberOfMessages) {

                        JOptionPane.showMessageDialog(
                                null,
                                "You have reached the number "
                                + "of messages you selected."
                        );

                        break;
                    }

                    String recipient
                            = JOptionPane.showInputDialog(
                                    "Enter the recipient's "
                                    + "cell phone number using "
                                    + "an international code:"
                            );

                    if (recipient == null) {
                        break;
                    }

                    String messageText
                            = JOptionPane.showInputDialog(
                                    "Enter your message:"
                            );

                    if (messageText == null) {
                        break;
                    }

                    String messageID
                            = Message.generateMessageID();

                    Message newMessage
                            = new Message(
                                    messageID,
                                    messagesCreated,
                                    recipient,
                                    messageText
                            );

                    // Check Message ID
                    if (!newMessage.checkMessageID()) {

                        JOptionPane.showMessageDialog(
                                null,
                                "Message ID is invalid."
                        );

                        break;
                    }

                    // Check recipient
                    String recipientResult
                            = newMessage.checkRecipientCell();

                    JOptionPane.showMessageDialog(
                            null,
                            recipientResult
                    );

                    if (!recipientResult.equals(
                            "Cell phone number successfully captured.")) {

                        break;
                    }

                    // Check message length
                    String lengthResult
                            = newMessage.checkMessageLength();

                    JOptionPane.showMessageDialog(
                            null,
                            lengthResult
                    );

                    if (!lengthResult.equals(
                            "Message ready to send.")) {

                        break;
                    }

                    // Display Message ID and Hash
                    JOptionPane.showMessageDialog(
                            null,
                            "Message ID: "
                            + newMessage.getMessageID()
                            + "\nMessage Hash: "
                            + newMessage.createMessageHash()
                    );

                    // Send, discard or store
                    String sendResult
                            = newMessage.SentMessage();

                    JOptionPane.showMessageDialog(
                            null,
                            sendResult
                    );

                    // If message was sent,
                    // display full information
                    if (sendResult.equals(
                            "Message successfully sent.")) {

                        JOptionPane.showMessageDialog(
                                null,
                                "Message ID: "
                                + newMessage.getMessageID()
                                + "\nMessage Hash: "
                                + newMessage.createMessageHash()
                                + "\nRecipient: "
                                + newMessage.getRecipient()
                                + "\nMessage: "
                                + newMessage.getMessage()
                        );
                    }

                    messagesCreated++;

                    lastMessage = newMessage;

                    break;

                // =========================================
                // OPTION 2
                // =========================================

                case "2":

                    JOptionPane.showMessageDialog(
                            null,
                            "Coming Soon."
                    );

                    break;

                // =========================================
                // OPTION 3
                // =========================================

                case "3":

                    running = false;

                    break;

                // =========================================
                // INVALID OPTION
                // =========================================

                default:

                    JOptionPane.showMessageDialog(
                            null,
                            "Invalid option. "
                            + "Please select 1, 2 or 3."
                    );

                    break;
            }
        }

        // =================================================
        // TOTAL MESSAGES SENT
        // =================================================

        if (lastMessage != null) {

            JOptionPane.showMessageDialog(
                    null,
                    "Total messages sent: "
                    + lastMessage.returnTotalMessages()
            );

        } else {

            JOptionPane.showMessageDialog(
                    null,
                    "Total messages sent: 0"
            );
        }
    }
}
    

