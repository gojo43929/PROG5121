package com.mycompany.mavenproject4;

import javax.swing.JOptionPane;

public class Mavenproject4 {

    public static void main(String[] args) {

        // =====================================================
        // PART 1 - REGISTRATION
        // =====================================================

        String firstName = JOptionPane.showInputDialog(
                "Enter your first name:");

        String lastName = JOptionPane.showInputDialog(
                "Enter your last name:");

        String username = JOptionPane.showInputDialog(
                "Enter your username:");

        String password = JOptionPane.showInputDialog(
                "Enter your password:");

        String cellPhoneNumber = JOptionPane.showInputDialog(
                "Enter your South African cell phone number "
                + "using the international code, e.g. +27838968976:");

        Login user = new Login(
                firstName,
                lastName,
                username,
                password,
                cellPhoneNumber
        );

        // Username validation
        if (user.checkUserName()) {

            JOptionPane.showMessageDialog(
                    null,
                    "Username successfully captured."
            );

        } else {

            JOptionPane.showMessageDialog(
                    null,
                    "Username is not correctly formatted; please ensure "
                    + "that your username contains an underscore and is "
                    + "no more than five characters in length."
            );
        }

        // Password validation
        if (user.checkPasswordComplexity()) {

            JOptionPane.showMessageDialog(
                    null,
                    "Password successfully captured."
            );

        } else {

            JOptionPane.showMessageDialog(
                    null,
                    "Password is not correctly formatted; please ensure "
                    + "that the password contains at least eight characters, "
                    + "a capital letter, a number, and a special character."
            );
        }

        // Cellphone validation
        if (user.checkCellPhoneNumber()) {

            JOptionPane.showMessageDialog(
                    null,
                    "Cell phone number successfully added."
            );

        } else {

            JOptionPane.showMessageDialog(
                    null,
                    "Cell phone number incorrectly formatted or does not "
                    + "contain international code."
            );
        }

        // Registration result
        JOptionPane.showMessageDialog(
                null,
                user.registerUser()
        );

        // Stop if registration is invalid
        if (!user.checkUserName()
                || !user.checkPasswordComplexity()
                || !user.checkCellPhoneNumber()) {

            JOptionPane.showMessageDialog(
                    null,
                    "Registration was unsuccessful."
            );

            return;
        }

        // =====================================================
        // PART 1 - LOGIN
        // =====================================================

        String loginUsername = JOptionPane.showInputDialog(
                "Enter your username to login:");

        String loginPassword = JOptionPane.showInputDialog(
                "Enter your password to login:");

        user.setLoginDetails(
                loginUsername,
                loginPassword
        );

        if (user.loginUser()) {

            JOptionPane.showMessageDialog(
                    null,
                    user.returnLoginStatus()
            );

            // START PART 2
            startQuickChat();

        } else {

            JOptionPane.showMessageDialog(
                    null,
                    "Username or password incorrect, please try again."
            );
        }
    }

    // =========================================================
    // PART 2 - QUICKCHAT
    // =========================================================

    public static void startQuickChat() {

        JOptionPane.showMessageDialog(
                null,
                "Welcome to QuickChat."
        );

        // Ask user how many messages they want to enter
        String numberInput = JOptionPane.showInputDialog(
                "How many messages would you like to enter?"
        );

        if (numberInput == null) {
            return;
        }

        int numberOfMessages;

        try {

            numberOfMessages = Integer.parseInt(numberInput);

            if (numberOfMessages <= 0) {

                JOptionPane.showMessageDialog(
                        null,
                        "Please enter a number greater than zero."
                );

                return;
            }

        } catch (NumberFormatException e) {

            JOptionPane.showMessageDialog(
                    null,
                    "Please enter a valid number."
            );

            return;
        }

        int messagesCreated = 0;

        Message lastMessage = null;

        boolean running = true;

        // =====================================================
        // QUICKCHAT MENU
        // =====================================================

        while (running) {

            String menuChoice = JOptionPane.showInputDialog(
                    "QuickChat\n\n"
                    + "1) Send Messages\n"
                    + "2) Show recently sent messages\n"
                    + "3) Quit\n\n"
                    + "Enter your choice:"
            );

            if (menuChoice == null) {
                break;
            }

            switch (menuChoice) {

                // =============================================
                // OPTION 1 - SEND MESSAGE
                // =============================================

                case "1":

                    if (messagesCreated >= numberOfMessages) {

                        JOptionPane.showMessageDialog(
                                null,
                                "You have reached the number of messages "
                                + "you selected."
                        );

                        break;
                    }

                    String recipient
                            = JOptionPane.showInputDialog(
                                    "Enter the recipient's cell phone number "
                                    + "using an international code:"
                            );

                    if (recipient == null) {
                        break;
                    }

                    String messageText
                            = JOptionPane.showInputDialog(
                                    "Enter your message:"
                            );

                    if (messageText == null) {
                        break;
                    }

                    // Generate Message ID
                    String messageID
                            = Message.generateMessageID();

                    // Create Message object
                    Message newMessage = new Message(
                            messageID,
                            messagesCreated,
                            recipient,
                            messageText
                    );

                    // Check Message ID
                    if (!newMessage.checkMessageID()) {

                        JOptionPane.showMessageDialog(
                                null,
                                "Message ID is invalid."
                        );

                        break;
                    }

                    // Check recipient
                    String recipientResult
                            = newMessage.checkRecipientCell();

                    JOptionPane.showMessageDialog(
                            null,
                            recipientResult
                    );

                    if (!recipientResult.equals(
                            "Cell phone number successfully captured.")) {

                        break;
                    }

                    // Check message length
                    String lengthResult
                            = newMessage.checkMessageLength();

                    JOptionPane.showMessageDialog(
                            null,
                            lengthResult
                    );

                    if (!lengthResult.equals(
                            "Message ready to send.")) {

                        break;
                    }

                    // Display Message ID
                    JOptionPane.showMessageDialog(
                            null,
                            "Message ID: "
                            + newMessage.getMessageID()
                    );

                    // Display Message Hash
                    JOptionPane.showMessageDialog(
                            null,
                            "Message Hash: "
                            + newMessage.createMessageHash()
                    );

                    // Send, disregard or store
                    String sendResult
                            = newMessage.SentMessage();

                    JOptionPane.showMessageDialog(
                            null,
                            sendResult
                    );

                    // Display complete message if sent
                    if (sendResult.equals(
                            "Message successfully sent.")) {

                        JOptionPane.showMessageDialog(
                                null,
                                "Message ID: "
                                + newMessage.getMessageID()
                                + "\nMessage Hash: "
                                + newMessage.createMessageHash()
                                + "\nRecipient: "
                                + newMessage.getRecipient()
                                + "\nMessage: "
                                + newMessage.getMessage()
                        );
                    }

                    messagesCreated++;

                    lastMessage = newMessage;

                    break;

                // =============================================
                // OPTION 2
                // =============================================

                case "2":

                    JOptionPane.showMessageDialog(
                            null,
                            "Coming Soon."
                    );

                    break;

                // =============================================
                // OPTION 3
                // =============================================

                case "3":

                    running = false;

                    break;

                default:

                    JOptionPane.showMessageDialog(
                            null,
                            "Invalid option. Please select 1, 2 or 3."
                    );

                    break;
            }
        }

        // =====================================================
        // TOTAL MESSAGES SENT
        // =====================================================

        if (lastMessage != null) {

            JOptionPane.showMessageDialog(
                    null,
                    "Total messages sent: "
                    + lastMessage.returnTotalMessages()
            );

        } else {

            JOptionPane.showMessageDialog(
                    null,
                    "Total messages sent: 0"
            );
        }
    }
}
            
