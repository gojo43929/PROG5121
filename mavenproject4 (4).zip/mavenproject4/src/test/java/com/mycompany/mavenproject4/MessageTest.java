
package com.mycompany.mavenproject4;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class MessageTest {

    private Message first;
    private Message second;
    private Message third;
    private Message fourth;
    private Message fifth;

    // SET UP THE FIVE ASSIGNMENT TEST MESSAGES
    @BeforeEach
    public void setup() {

        Message.clearAllMessages();

        first = new Message(
                "0012345678",
                0,
                "+27834557896",
                "Did you get the cake?"
        );

        second = new Message(
                "0112345678",
                1,
                "+27838884567",
                "Where are you? You are late! I have asked "
                + "you to be on time."
        );

        third = new Message(
                "0212345678",
                2,
                "+27834484567",
                "Yohoooo, I am at your gate."
        );

        fourth = new Message(
                "0838884567",
                3,
                "0838884567",
                "It is dinner time !"
        );

        fifth = new Message(
                "0412345678",
                4,
                "+27838884567",
                "Ok, I am leaving without you."
        );

        Message.addSentMessage(first);
        Message.addStoredMessage(second);
        Message.addDisregardedMessage(third);
        Message.addSentMessage(fourth);
        Message.addStoredMessage(fifth);
    }

    // TEST 1 - SENT MESSAGES ARRAY
    @Test
    public void sentMessagesArrayCorrectlyPopulated() {

        assertEquals(2, Message.getSentMessages().size());

        assertEquals(
                "Did you get the cake?",
                Message.getSentMessages().get(0).getMessage()
        );

        assertEquals(
                "It is dinner time !",
                Message.getSentMessages().get(1).getMessage()
        );
    }

    // TEST 2 - DISREGARDED MESSAGES ARRAY
    @Test
    public void disregardedMessagesArrayCorrectlyPopulated() {

        assertEquals(
                1,
                Message.getDisregardedMessages().size()
        );

        assertEquals(
                "Yohoooo, I am at your gate.",
                Message.getDisregardedMessages().get(0).getMessage()
        );
    }

    // TEST 3 - STORED MESSAGES ARRAY
    @Test
    public void storedMessagesArrayCorrectlyPopulated() {

        assertEquals(
                2,
                Message.getStoredMessages().size()
        );

        assertEquals(
                "Where are you? You are late! I have asked "
                + "you to be on time.",
                Message.getStoredMessages().get(0).getMessage()
        );
    }

    // TEST 4 - LONGEST MESSAGE
    @Test
    public void displayLongestMessage() {

        assertEquals(
                "Where are you? You are late! I have asked "
                + "you to be on time.",
                Message.displayLongestMessage()
        );
    }

    // TEST 5 - SEARCH BY MESSAGE ID
    @Test
    public void searchForMessageID() {

        String result = Message.searchMessageID("0838884567");

        assertTrue(result.contains("It is dinner time !"));

        assertTrue(result.contains("0838884567"));
    }

    // TEST 6 - SEARCH BY RECIPIENT
    @Test
    public void searchAllMessagesForRecipient() {

        String result = Message.searchRecipient("+27838884567");

        assertTrue(result.contains(
                "Where are you? You are late! I have asked "
                + "you to be on time."
        ));

        assertTrue(result.contains(
                "Ok, I am leaving without you."
        ));
    }

    // TEST 7 - DELETE MESSAGE USING HASH
    @Test
    public void deleteMessageByHash() {

        String result = Message.deleteMessageByHash(
                second.createMessageHash()
        );

        assertEquals(
                "Message: \"Where are you? You are late! "
                + "I have asked you to be on time.\" "
                + "successfully deleted.",
                result
        );

        assertEquals(
                1,
                Message.getStoredMessages().size()
        );
    }

    // TEST 8 - DISPLAY REPORT
    @Test
    public void displayReport() {

        String report = Message.displayReport();

        assertTrue(report.contains("Message Hash:"));
        assertTrue(report.contains("Recipient:"));

        assertTrue(report.contains(
                "Did you get the cake?"
        ));

        assertTrue(report.contains(
                "It is dinner time !"
        ));
    }

    // TEST 9 - MESSAGE HASHES AND IDS
    @Test
    public void messageHashAndIDsArrays() {

        assertEquals(
                5,
                Message.getMessageIDs().size()
        );

        assertEquals(
                5,
                Message.getMessageHashes().size()
        );
    }

    // TEST 10 - PART 2 MESSAGE HASH
    @Test
    public void part2MessageHash() {

        Message example = new Message(
                "0012345678",
                0,
                "+27718693002",
                "Hi Mike, can you join us for dinner tonight?"
        );

        assertEquals(
                "00:0:HITONIGHT",
                example.createMessageHash()
        );
    }

    // TEST 11 - PART 2 VALIDATION
    @Test
    public void part2MessageLengthAndRecipient() {

        Message example = new Message(
                "0012345678",
                0,
                "+27718693002",
                "Hello"
        );

        assertEquals(
                "Message ready to send.",
                example.checkMessageLength()
        );

        assertEquals(
                "Cell phone number successfully captured.",
                example.checkRecipientCell()
        );

        assertTrue(example.checkMessageID());
    }
}

