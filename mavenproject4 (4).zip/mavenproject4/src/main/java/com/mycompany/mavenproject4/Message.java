
package com.mycompany.mavenproject4;

import javax.swing.JOptionPane;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Message {

    private final String messageID;
    private final int messageNumber;
    private final String recipient;
    private final String message;
    private String flag = "";

    // PART 3 ARRAYS
    private static final List<Message> sentMessages = new ArrayList<>();
    private static final List<Message> disregardedMessages = new ArrayList<>();
    private static final List<Message> storedMessages = new ArrayList<>();
    private static final List<String> messageHashes = new ArrayList<>();
    private static final List<String> messageIDs = new ArrayList<>();

    private static final Path STORE = Paths.get("storedMessages.json");
    private static int totalMessages = 0;

    // CONSTRUCTOR
    public Message(String messageID, int messageNumber,
                   String recipient, String message) {
        this.messageID = messageID;
        this.messageNumber = messageNumber;
        this.recipient = recipient;
        this.message = message;
    }

    // GENERATE 10-DIGIT MESSAGE ID
    public static String generateMessageID() {
        Random random = new Random();
        StringBuilder result = new StringBuilder();

        for (int i = 0; i < 10; i++) {
            result.append(random.nextInt(10));
        }

        return result.toString();
    }

    // VALIDATE MESSAGE ID
    public boolean checkMessageID() {
        return messageID != null && messageID.matches("\\d{10}");
    }

    // VALIDATE RECIPIENT
    public String checkRecipientCell() {
        return recipient != null && recipient.matches("\\+\\d{10,12}")
                ? "Cell phone number successfully captured."
                : "Cell phone number is incorrectly formatted or does not "
                + "contain an international code. Please correct the "
                + "number and try again.";
    }

    // VALIDATE MESSAGE LENGTH
    public String checkMessageLength() {
        if (message == null) {
            return "Message cannot be empty.";
        }

        if (message.length() <= 250) {
            return "Message ready to send.";
        }

        return "Message exceeds 250 characters by "
                + (message.length() - 250)
                + ", please reduce the size.";
    }

    // CREATE MESSAGE HASH
    public String createMessageHash() {
        if (message == null || message.trim().isEmpty()) {
            return "";
        }

        String[] words = message.trim().split("\\s+");

        String first = words[0].replaceAll("[^a-zA-Z0-9]", "");
        String last = words[words.length - 1]
                .replaceAll("[^a-zA-Z0-9]", "");

        String prefix = messageID == null ? ""
                : messageID.substring(
                        0, Math.min(2, messageID.length()));

        return (prefix + ":" + messageNumber + ":"
                + first + last).toUpperCase();
    }

    // INDEX MESSAGE IDS AND HASHES
    private static void index(Message m) {
        if (!messageIDs.contains(m.messageID)) {
            messageIDs.add(m.messageID);
        }

        if (!messageHashes.contains(m.createMessageHash())) {
            messageHashes.add(m.createMessageHash());
        }
    }

    // ADD SENT MESSAGE
    public static void addSentMessage(Message m) {
        m.flag = "Sent";
        sentMessages.add(m);
        index(m);
        totalMessages++;
    }

    // ADD DISREGARDED MESSAGE
    public static void addDisregardedMessage(Message m) {
        m.flag = "Disregard";
        disregardedMessages.add(m);
        index(m);
    }

    // ADD STORED MESSAGE
    public static void addStoredMessage(Message m) {
        m.flag = "Stored";
        storedMessages.add(m);
        index(m);
    }

    // SEND / DISREGARD / STORE
    public String SentMessage() {
        String[] options = {
            "Send Message",
            "Disregard Message",
            "Store Message"
        };

        int choice = JOptionPane.showOptionDialog(
                null,
                "What would you like to do with this message?",
                "QuickChat",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.QUESTION_MESSAGE,
                null,
                options,
                options[0]
        );

        if (choice == 0) {
            addSentMessage(this);
            return "Message successfully sent.";
        }

        if (choice == 1) {
            addDisregardedMessage(this);
            return "Message disregarded.";
        }

        if (choice == 2) {
            addStoredMessage(this);

            try {
                saveStoredMessages();
                return "Message successfully stored.";
            } catch (IOException e) {
                return "Message stored in memory, but JSON save failed: "
                        + e.getMessage();
            }
        }

        return "Message not sent.";
    }

    // PRINT SENT MESSAGES
    public String printMessages() {
        if (sentMessages.isEmpty()) {
            return "No messages have been sent.";
        }

        StringBuilder out = new StringBuilder();

        for (Message m : sentMessages) {
            out.append(details(m)).append("\n\n");
        }

        return out.toString();
    }

    // FORMAT MESSAGE DETAILS
    private static String details(Message m) {
        return "Message ID: " + m.messageID
                + "\nMessage Hash: " + m.createMessageHash()
                + "\nRecipient: " + m.recipient
                + "\nMessage: " + m.message;
    }

    // RETURN TOTAL SENT MESSAGES
    public int returnTotalMessages() {
        return totalMessages;
    }

    // DISPLAY SENDERS AND RECIPIENTS
    public static String displayStoredSendersRecipients() {
        if (storedMessages.isEmpty()) {
            return "No stored messages.";
        }

        StringBuilder out = new StringBuilder();

        for (Message m : storedMessages) {
            out.append("Sender: Developer\nRecipient: ")
                    .append(m.recipient)
                    .append("\n\n");
        }

        return out.toString();
    }

    // FIND LONGEST SENT OR STORED MESSAGE
    public static String displayLongestMessage() {
        Message longest = null;

        for (Message m : sentMessages) {
            if (longest == null
                    || m.message.length() > longest.message.length()) {
                longest = m;
            }
        }

        for (Message m : storedMessages) {
            if (longest == null
                    || m.message.length() > longest.message.length()) {
                longest = m;
            }
        }

        return longest == null
                ? "No messages available."
                : longest.message;
    }

    // SEARCH BY MESSAGE ID
    public static String searchMessageID(String id) {
        for (Message m : allMessages()) {
            if (m.messageID.equals(id)) {
                return "Recipient: " + m.recipient
                        + "\nMessage: " + m.message;
            }
        }

        return "Message ID not found.";
    }

    // SEARCH BY RECIPIENT
    public static String searchRecipient(String recipient) {
        StringBuilder out = new StringBuilder();

        for (Message m : sentMessages) {
            if (m.recipient.equals(recipient)) {
                out.append(m.message).append("\n");
            }
        }

        for (Message m : storedMessages) {
            if (m.recipient.equals(recipient)) {
                out.append(m.message).append("\n");
            }
        }

        return out.length() == 0
                ? "No messages found for this recipient."
                : out.toString().trim();
    }

    // DELETE STORED MESSAGE USING HASH
    public static String deleteMessageByHash(String hash) {
        for (int i = 0; i < storedMessages.size(); i++) {
            Message m = storedMessages.get(i);

            if (m.createMessageHash().equalsIgnoreCase(hash)) {
                storedMessages.remove(i);
                rebuildIndexes();

                try {
                    saveStoredMessages();
                } catch (IOException e) {
                    return "Message removed from memory, but JSON "
                            + "update failed: " + e.getMessage();
                }

                return "Message: \"" + m.message
                        + "\" successfully deleted.";
            }
        }

        return "Message hash not found.";
    }

    // DISPLAY FULL REPORT
    public static String displayReport() {
        if (sentMessages.isEmpty() && storedMessages.isEmpty()) {
            return "No messages available.";
        }

        StringBuilder out = new StringBuilder("MESSAGE REPORT\n\n");

        for (Message m : sentMessages) {
            out.append(details(m))
                    .append("\nStatus: Sent\n\n");
        }

        for (Message m : storedMessages) {
            out.append(details(m))
                    .append("\nStatus: Stored\n\n");
        }

        return out.toString();
    }

    // COMBINE ALL MESSAGE ARRAYS
    private static List<Message> allMessages() {
        List<Message> all = new ArrayList<>(sentMessages);
        all.addAll(storedMessages);
        all.addAll(disregardedMessages);
        return all;
    }

    // REBUILD MESSAGE ID AND HASH ARRAYS
    private static void rebuildIndexes() {
        messageIDs.clear();
        messageHashes.clear();

        for (Message m : allMessages()) {
            index(m);
        }
    }

    // RESET ARRAYS FOR UNIT TESTING
    public static void clearAllMessages() {
        sentMessages.clear();
        disregardedMessages.clear();
        storedMessages.clear();
        messageHashes.clear();
        messageIDs.clear();
        totalMessages = 0;
    }

    // ARRAY GETTERS
    public static List<Message> getSentMessages() {
        return new ArrayList<>(sentMessages);
    }

    public static List<Message> getDisregardedMessages() {
        return new ArrayList<>(disregardedMessages);
    }

    public static List<Message> getStoredMessages() {
        return new ArrayList<>(storedMessages);
    }

    public static List<String> getMessageHashes() {
        return new ArrayList<>(messageHashes);
    }

    public static List<String> getMessageIDs() {
        return new ArrayList<>(messageIDs);
    }

    // OBJECT GETTERS
    public String getMessageID() {
        return messageID;
    }

    public int getMessageNumber() {
        return messageNumber;
    }

    public String getRecipient() {
        return recipient;
    }

    public String getMessage() {
        return message;
    }

    public String getFlag() {
        return flag;
    }

    // ESCAPE JSON CHARACTERS
    private static String escapeJson(String s) {
        return s.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "\\r")
                .replace("\t", "\\t");
    }

    // UNESCAPE JSON CHARACTERS
    private static String unescapeJson(String s) {
        StringBuilder out = new StringBuilder();

        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);

            if (c == '\\' && i + 1 < s.length()) {
                char next = s.charAt(++i);

                switch (next) {
                    case 'n':
                        out.append('\n');
                        break;
                    case 'r':
                        out.append('\r');
                        break;
                    case 't':
                        out.append('\t');
                        break;
                    case '"':
                        out.append('"');
                        break;
                    case '\\':
                        out.append('\\');
                        break;
                    default:
                        out.append(next);
                }
            } else {
                out.append(c);
            }
        }

        return out.toString();
    }

    // SAVE STORED MESSAGES AS JSON ARRAY
    public static void saveStoredMessages() throws IOException {
        StringBuilder json = new StringBuilder("[\n");

        for (int i = 0; i < storedMessages.size(); i++) {
            Message m = storedMessages.get(i);

            if (i > 0) {
                json.append(",\n");
            }

            json.append("  {\"messageID\":\"")
                    .append(escapeJson(m.messageID))
                    .append("\",\"messageNumber\":")
                    .append(m.messageNumber)
                    .append(",\"recipient\":\"")
                    .append(escapeJson(m.recipient))
                    .append("\",\"message\":\"")
                    .append(escapeJson(m.message))
                    .append("\",\"messageHash\":\"")
                    .append(escapeJson(m.createMessageHash()))
                    .append("\"}");
        }

        json.append("\n]\n");

        Files.write(
                STORE,
                json.toString().getBytes(StandardCharsets.UTF_8)
        );
    }

    // LOAD STORED MESSAGES FROM JSON FILE
    public static void loadStoredMessages() throws IOException {
        if (!Files.exists(STORE)) {
            return;
        }

        String json = new String(
                Files.readAllBytes(STORE),
                StandardCharsets.UTF_8
        );

        String quoted = "\"((?:\\\\.|[^\"\\\\])*)\"";

        String regex = "\\{\\s*\"messageID\"\\s*:\\s*" + quoted
                + "\\s*,\\s*\"messageNumber\"\\s*:\\s*(\\d+)"
                + "\\s*,\\s*\"recipient\"\\s*:\\s*" + quoted
                + "\\s*,\\s*\"message\"\\s*:\\s*" + quoted
                + "\\s*,\\s*\"messageHash\"\\s*:\\s*"
                + quoted + "\\s*\\}";

        Matcher matcher = Pattern.compile(regex).matcher(json);
        List<Message> loaded = new ArrayList<>();

        while (matcher.find()) {
            Message m = new Message(
                    unescapeJson(matcher.group(1)),
                    Integer.parseInt(matcher.group(2)),
                    unescapeJson(matcher.group(3)),
                    unescapeJson(matcher.group(4))
            );

            m.flag = "Stored";
            loaded.add(m);
        }

        if (!json.trim().startsWith("[")
                || !json.trim().endsWith("]")
                || (!json.replaceAll("\\s", "").equals("[]")
                && loaded.isEmpty())) {

            throw new IOException(
                    "Stored messages file is not in the expected "
                    + "JSON array format."
            );
        }

        storedMessages.clear();
        storedMessages.addAll(loaded);
        rebuildIndexes();
    }

    // STORE A SINGLE MESSAGE
    public void storeMessage() {
        if (!storedMessages.contains(this)) {
            addStoredMessage(this);
        }

        try {
            saveStoredMessages();
        } catch (IOException e) {
            JOptionPane.showMessageDialog(
                    null,
                    "Error storing message: " + e.getMessage()
            );
        }
    }

    // =====================================================
    // MAIN METHOD - PART 2 AND PART 3
    // =====================================================
    public static void main(String[] args) {

        clearAllMessages();

        try {
            loadStoredMessages();
        } catch (IOException e) {
            JOptionPane.showMessageDialog(
                    null,
                    "Could not load stored messages: "
                    + e.getMessage()
            );
        }

        JOptionPane.showMessageDialog(
                null,
                "Welcome to QuickChat."
        );

        String countText = JOptionPane.showInputDialog(
                "How many messages would you like to enter?"
        );

        if (countText == null) {
            return;
        }

        int limit;

        try {
            limit = Integer.parseInt(countText.trim());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(
                    null,
                    "Please enter a valid number."
            );
            return;
        }

        if (limit <= 0) {
            JOptionPane.showMessageDialog(
                    null,
                    "Please enter a number greater than zero."
            );
            return;
        }

        int created = 0;

        while (true) {

            String choice = JOptionPane.showInputDialog(
                    "QuickChat\n\n"
                    + "1) Send Messages\n"
                    + "2) Show recently sent messages\n"
                    + "3) Quit\n"
                    + "4) Stored Messages\n\n"
                    + "Enter your choice:"
            );

            if (choice == null || choice.equals("3")) {
                break;
            }

            switch (choice) {

                case "1": {
                    if (created >= limit) {
                        JOptionPane.showMessageDialog(
                                null,
                                "You have reached your message limit."
                        );
                        break;
                    }

                    String to = JOptionPane.showInputDialog(
                            "Enter the recipient's cell number "
                            + "with international code:"
                    );

                    if (to == null) {
                        break;
                    }

                    String body = JOptionPane.showInputDialog(
                            "Enter your message:"
                    );

                    if (body == null) {
                        break;
                    }

                    Message m = new Message(
                            generateMessageID(),
                            created,
                            to,
                            body
                    );

                    if (!m.checkMessageID()) {
                        JOptionPane.showMessageDialog(
                                null,
                                "Message ID is invalid."
                        );
                        break;
                    }

                    if (!m.checkRecipientCell().equals(
                            "Cell phone number successfully captured.")) {

                        JOptionPane.showMessageDialog(
                                null,
                                m.checkRecipientCell()
                        );
                        break;
                    }

                    if (!m.checkMessageLength().equals(
                            "Message ready to send.")) {

                        JOptionPane.showMessageDialog(
                                null,
                                m.checkMessageLength()
                        );
                        break;
                    }

                    JOptionPane.showMessageDialog(
                            null,
                            details(m)
                    );

                    String result = m.SentMessage();

                    JOptionPane.showMessageDialog(
                            null,
                            result
                    );

                    if (!result.equals("Message not sent.")) {
                        created++;
                    }

                    break;
                }

                case "2":
                    JOptionPane.showMessageDialog(
                            null,
                            sentMessages.isEmpty()
                                    ? "Coming Soon."
                                    : sentMessages.get(0).printMessages()
                    );
                    break;

                case "4":
                    showStoredMessagesMenu();
                    break;

                default:
                    JOptionPane.showMessageDialog(
                            null,
                            "Invalid option. Select 1, 2, 3 or 4."
                    );
            }
        }

        JOptionPane.showMessageDialog(
                null,
                "Total messages sent: " + totalMessages
        );
    }

    // =====================================================
    // PART 3 - STORED MESSAGES MENU
    // =====================================================
    public static void showStoredMessagesMenu() {

        while (true) {

            String choice = JOptionPane.showInputDialog(
                    "Stored Messages\n\n"
                    + "1) Display senders and recipients\n"
                    + "2) Display longest message\n"
                    + "3) Search by Message ID\n"
                    + "4) Search by recipient\n"
                    + "5) Delete by message hash\n"
                    + "6) Display report\n"
                    + "7) Return to main menu"
            );

            if (choice == null || choice.equals("7")) {
                return;
            }

            switch (choice) {

                case "1":
                    JOptionPane.showMessageDialog(
                            null,
                            displayStoredSendersRecipients()
                    );
                    break;

                case "2":
                    JOptionPane.showMessageDialog(
                            null,
                            displayLongestMessage()
                    );
                    break;

                case "3": {
                    String id = JOptionPane.showInputDialog(
                            "Enter Message ID:"
                    );

                    if (id != null) {
                        JOptionPane.showMessageDialog(
                                null,
                                searchMessageID(id)
                        );
                    }
                    break;
                }

                case "4": {
                    String recipient = JOptionPane.showInputDialog(
                            "Enter recipient number:"
                    );

                    if (recipient != null) {
                        JOptionPane.showMessageDialog(
                                null,
                                searchRecipient(recipient)
                        );
                    }
                    break;
                }

                case "5": {
                    String hash = JOptionPane.showInputDialog(
                            "Enter Message Hash:"
                    );

                    if (hash != null) {
                        JOptionPane.showMessageDialog(
                                null,
                                deleteMessageByHash(hash)
                        );
                    }
                    break;
                }

                case "6":
                    JOptionPane.showMessageDialog(
                            null,
                            displayReport()
                    );
                    break;

                default:
                    JOptionPane.showMessageDialog(
                            null,
                            "Invalid option."
                    );
            }
        }
    }
}
